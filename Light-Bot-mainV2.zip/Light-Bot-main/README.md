# LightBot Python - Comparacin A* vs BFS

## Descripcin del Proyecto

Este proyecto implementa una versin simplificada del juego LightBot en Python donde un robot debe encender todas las luces azules en un tablero. El objetivo principal es comparar la eficiencia de dos algoritmos de bsqueda:

- **A*** (con heurstica)
- **BFS** (bsqueda ciega)

## Reglas del Juego Simplificado

1. **Movimiento**: El robot puede moverse instantneamente en 4 direcciones (arriba, abajo, izquierda, derecha) sin necesidad de girar.

2. **Objetivo**: Encender todas las luces azules del tablero.

3. **Acciones disponibles**:
   - **MOVER**: A una casilla adyacente (si no es obstculo)
   - **ENCENDER**: La luz en la posicin actual (si hay una luz apagada)

## Representacin del Tablero

- **0**: Piso normal (el robot puede caminar)
- **1**: Obstculo (el robot NO puede pasar)
- **2**: Casilla objetivo con luz azul (debe ser encendida)

## Algoritmos Implementados

### A* (A-Star)
- Utiliza una heurstica optimista: `h(n) = luces_apagadas + distancia_a_luz_ms_cercana`
- Explora nodos de manera inteligente priorizando los ms prometedores
- Garantiza encontrar la solucin ptima

### BFS (Breadth-First Search)
- Bsqueda ciega que explora todos los nodos nivel por nivel
- No utiliza informacin heurstica
- Garantiza encontrar la solucin ptima pero puede ser menos eficiente

## Estructura del Cdigo

### Archivos Principales

1. **node.py**: Representa un estado del juego (posicin del robot + estado de luces)
2. **game_state.py**: Maneja las reglas del juego y generacin de sucesores
3. **astar.py**: Implementacin del algoritmo A*
4. **bfs.py**: Implementacin del algoritmo BFS
5. **game_renderer.py**: Renderizado en consola del juego
6. **priority_queue.py**: Cola de prioridad para A*
7. **levels.py**: Definicin de los 3 niveles
8. **lightbot_game.py**: Clase principal del juego

### Niveles Incluidos

1. **Nivel 1**: Tablero 3x3 con 2 luces
2. **Nivel 2**: Tablero 4x4 con 3 luces y obstculos
3. **Nivel 3**: Tablero 5x5 con 4 luces en laberinto complejo

## Cmo Ejecutar

```bash
python lightbot_game.py
```

## Funcionalidades

1. **Resolucin Automtica**: Ve cmo A* y BFS resuelven cada nivel
2. **Comparacin de Rendimiento**: Estadsticas detalladas de ambos algoritmos
3. **Modo Manual**: Juega t mismo e intenta encontrar el camino ptimo
4. **Anlisis Completo**: Compara el rendimiento en todos los niveles

## Mtricas de Comparacin

Para cada algoritmo se muestran:
- **Nodos explorados**: Cantidad de estados visitados
- **Pasos de la solucin**: Longitud del camino encontrado
- **Tiempo de ejecucin**: Tiempo en milisegundos

## Resultados Esperados

Generalmente A* debera:
- Explorar menos nodos que BFS
- Encontrar la solucin en menos tiempo
- Mantener la optimalidad de la solucin

Esto demuestra la ventaja de usar informacin heurstica en problemas de bsqueda.

## Ejemplo de Uso

```
 LIGHTBOT - Comparacin de algoritmos A* vs BFS
==================================================

MEN PRINCIPAL
==================================================
1. Resolver Nivel 1 (Bsico)
2. Resolver Nivel 2 (Intermedio)
3. Resolver Nivel 3 (Avanzado)
4. Comparar todos los niveles
5. Juego manual (adivinar camino)
6. Salir

Selecciona una opcin: 1

=== Nivel Bsico ===
Descripcin: Dos luces simples

 R   .   L 
 .   #   . 
 .   .   L 

Resolviendo con A*...
Resolviendo con BFS...

=== COMPARACIN DE ALGORITMOS ===

A* (Heurstica):
  Nodos explorados: 8
  Pasos solucin: 6
  Tiempo: 0.15ms

BFS (Bsqueda Ciega):
  Nodos explorados: 12
  Pasos solucin: 6
  Tiempo: 0.23ms

=== ANLISIS ===
A* explor 33.3% menos nodos que BFS
A* fue 34.8% ms rpido que BFS

Solucin encontrada:
  1. DERECHA
  2. DERECHA
  3. ENCENDER
  4. ABAJO
  5. ABAJO
  6. ENCENDER
```