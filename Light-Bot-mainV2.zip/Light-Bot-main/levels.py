"""
Definicion de los niveles del juego
0: Piso normal
1: Obstaculo
2: Luz (objetivo)
"""

LEVELS = {
    1: {
        'grid': [
            [0, 0, 2],
            [0, 1, 0],
            [0, 0, 2]
        ],
        'robot_start': (0, 0),
        'name': "Nivel Basico",
        'description': "Tablero pequeno con dos luces y un obstaculo central",
        'difficulty': "Basico",
        'conditions': [
            "Solo 2 luces en extremos",
            "Un unico obstaculo que obliga a rodear",
            "Ramas de busqueda limitadas, camino corto"
        ]
    },
    2: {
        'grid': [
            [0, 2, 0, 1, 0],
            [0, 1, 0, 1, 0],
            [0, 0, 2, 0, 0],
            [0, 1, 0, 1, 0],
            [0, 0, 0, 2, 0]
        ],
        'robot_start': (2, 0),
        'name': "Nivel Intermedio",
        'description': "Tres luces con pasillos y obstaculos creando desvíos",
        'difficulty': "Intermedio",
        'conditions': [
            "3 luces separadas por pasillos",
            "Obstaculos creando cuellos de botella y desvíos",
            "Requiere planificar orden de encendido para evitar recorridos extra"
        ]
    },
    3: {
        'grid': [
            [0, 1, 2, 0, 0],
            [0, 0, 0, 1, 2],
            [1, 0, 1, 0, 0],
            [2, 0, 0, 0, 1],
            [0, 0, 2, 0, 0]
        ],
        'robot_start': (0, 0),
        'name': "Nivel Avanzado",
        'description': "Cuatro luces en un laberinto con varios bloqueos",
        'difficulty': "Avanzado",
        'conditions': [
            "4 luces en posiciones alejadas",
            "Laberinto con obstaculos que generan rutas largas y rodeos",
            "Mayor espacio de estados; el orden de visita impacta mucho el costo"
        ]
    }
}

def get_level(level_number):
    """Obtiene la configuracion de un nivel especifico"""
    return LEVELS.get(level_number, LEVELS[1])
