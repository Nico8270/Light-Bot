
"""
LightBot - Modo Adivinanza (minimal, sin emojis)
- Menu: Adivinanza | Salir
- Durante la captura de pasos, se muestra el estado tras cada accion
- Al terminar, se compara la solucion del jugador con A* y se ofrece Nueva Partida
- Controles: 1=IZQUIERDA, 2=ARRIBA, 3=DERECHA, 4=ABAJO, 5=ENCENDER
"""
from game_state import GameState
from game_renderer import GameRenderer
from levels import get_level
from astar import AStar

class LightBotGame:
    def __init__(self):
        self.renderer = GameRenderer()
        self.current_level = None
        self.game_state = None

    def start(self):
        """Menu minimo"""
        while True:
            print("\n" + "="*50)
            print("LIGHT-BOT - MODO ADIVINANZA (MINIMAL)")
            print("="*50)
            print("1. Modo adivinanza")
            print("2. Salir")
            print()
            choice = input("Selecciona una opcion (1-2): ").strip()

            if choice == '1':
                self._user_guess_mode()
            elif choice == '2' or choice.upper() == 'SALIR':
                print("Saliendo... Hasta luego!")
                break
            else:
                print("Opcion invalida. Intenta nuevamente.")

    def _simulate_until(self, level, start_xy, path, show_each=False):
        """Simula la ruta 'path' desde start_xy. Retorna (ultimo_nodo, valido_hasta_el_final)."""
        gs = GameState(level['grid'], start_xy[0], start_xy[1])
        current = gs.get_initial_node()

        if show_each:
            print("\nVista paso a paso (simulacion parcial):")

        for i, action in enumerate(path, 1):
            next_node = None
            if action in ('ARRIBA','ABAJO','IZQUIERDA','DERECHA'):
                dx, dy = 0, 0
                if action == 'ARRIBA':
                    dx, dy = -1, 0
                elif action == 'ABAJO':
                    dx, dy = 1, 0
                elif action == 'IZQUIERDA':
                    dx, dy = 0, -1
                elif action == 'DERECHA':
                    dx, dy = 0, 1

                new_x = current.x + dx
                new_y = current.y + dy
                if gs.can_move_to(new_x, new_y):
                    next_node = type(current)(new_x, new_y, current.lights, current, action, current.cost + 1)
                else:
                    print(f"  Paso {i}: {action} -> movimiento invalido contra pared/obstaculo")
                    return current, False

            elif action == 'ENCENDER':
                # Buscar indice de luz en la posicion actual
                light_index = None
                for idx,(lx,ly) in enumerate(gs.light_positions):
                    if lx == current.x and ly == current.y:
                        light_index = idx
                        break
                if light_index is not None and current.lights[light_index] == 0:
                    new_lights = list(current.lights)
                    new_lights[light_index] = 1
                    next_node = type(current)(current.x, current.y, tuple(new_lights), current, action, current.cost + 1)
                else:
                    print(f"  Paso {i}: {action} -> no hay luz para encender en esta posicion o ya estaba encendida")
                    return current, False
            else:
                print(f"  Paso {i}: {action} -> comando invalido")
                return current, False

            current = next_node
            if show_each:
                print(f"  Paso {i}: {action} -> pos=({current.x},{current.y}) luces={list(current.lights)}")

        return current, True

    def _user_guess_mode(self):
        """Modo adivinanza con controles numericos 1-5 y vista paso a paso"""
        print("\nMODO ADIVINANZA")
        print("=" * 50)

        # Seleccionar nivel
        while True:
            try:
                level_num = int(input("Selecciona nivel (1-3): ").strip())
                if 1 <= level_num <= 3:
                    break
                else:
                    print("Nivel debe estar entre 1 y 3")
            except ValueError:
                print("Por favor ingresa un numero valido")

        level = get_level(level_num)
        robot_x, robot_y = level['robot_start']

        # Estado base
        self.game_state = GameState(level['grid'], robot_x, robot_y)
        self.renderer.render_level(level, robot_x, robot_y)

        print("Controles disponibles (puedes usar numero o palabra):")
        print("  1 o IZQUIERDA")
        print("  2 o ARRIBA")
        print("  3 o DERECHA")
        print("  4 o ABAJO")
        print("  5 o ENCENDER (solo enciende)")
        print("  FIN para terminar la secuencia")
        print()

        keymap = {'1':'IZQUIERDA','2':'ARRIBA','3':'DERECHA','4':'ABAJO','5':'ENCENDER'}
        valid_words = {'ARRIBA','ABAJO','IZQUIERDA','DERECHA','ENCENDER'}

        user_path = []
        print("Ingresa tu solucion paso a paso (escribe 'FIN' para terminar).")
        print("Mientras ingresas pasos, te mostrare el estado actual.")

        while True:
            step = input(f"Paso {len(user_path)+1}: ").strip().upper()

            if step == 'FIN':
                break
            if step in keymap:
                cmd = keymap[step]
            elif step in valid_words:
                cmd = step
            else:
                print("  Comando invalido. Usa: 1/2/3/4/5 o ARRIBA/ABAJO/IZQUIERDA/DERECHA/ENCENDER, o FIN")
                continue

            # Agregar temporalmente y simular para mostrar estado
            temp_path = user_path + [cmd]
            last_node, ok = self._simulate_until(level, (robot_x, robot_y), temp_path, show_each=False)
            if not ok:
                print("  Ese paso no es valido desde el estado actual. Intenta con otro movimiento.")
                continue

            user_path.append(cmd)
            print(f"  Agregado: {cmd}")
            print(f"  Estado actual -> pos=({last_node.x},{last_node.y}) luces={list(last_node.lights)}")
            # Pintar tablero actualizado
            self.renderer.render_level(level, last_node.x, last_node.y, list(last_node.lights))

        if not user_path:
            print("No ingresaste ninguna solucion.")
            return

        # Evaluar solucion del usuario con detalle
        is_correct, user_steps = self.renderer.evaluate_user_solution(level, (robot_x, robot_y), user_path)

        # Comparar con A* (algoritmo estrella)
        print("\nComparando con A*:")
        astar_solver = AStar(GameState(level['grid'], robot_x, robot_y))
        result = astar_solver.solve()
        if result['success']:
            self.renderer.show_solution(result['path'], "A*")
            print(f"Pasos jugador: {len(user_path)} | Pasos A*: {result['steps']}")
        else:
            print("A* no encontro solucion.")

        # Ofrecer nueva partida al terminar el juego
        while True:
            again = input("\nDeseas iniciar una nueva partida? (S/N): ").strip().upper()
            if again == 'S':
                self._user_guess_mode()
                return
            elif again == 'N':
                return
            else:
                print("Responde con S o N.")

if __name__ == "__main__":
    LightBotGame().start()
